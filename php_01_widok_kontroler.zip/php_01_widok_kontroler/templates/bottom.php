</div><!-- content -->

<div class="footer">
	<p>
		<?php out($page_footer); if (!isset($page_footer)) {  ?> Domyślna zawartość stopki ... <?php } ?>
	</p>
	
</div>

</body>
</html>
