<?php
class CalcResult {
	public $op_name;
	public $result;	
} 